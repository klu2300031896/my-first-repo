import React from 'react'

const Home = () => {
  return (
    <div class="grid-layout">

        <div class="product">
            <img src="rose.jpg" alt="Product 1" />
            <h4>Product 1</h4>
            <p>$10.00</p>
            </div>
          <div class="product">
            <img src="rose.jpg" alt="Product 1" />
            <h4>Product 2</h4>
            <p>$10.00</p>
            </div>
          <div class="product">
            <img src="rose.jpg" alt="Product 1" />
            <h4>Product 3</h4>
            <p>$10.00</p>
            </div>
          <div class="product">
            <img src="rose.jpg" alt="Product 1" />
            <h4>Product 4</h4>
            <p>$10.00</p>
            </div>
    </div>
  )
}

export default Home